import datetime
import json
import csv
import os

class Caixa:
    def __init__(self, arquivo_vendas: str="data/vendas.json", arquivo_vendas_csv: str="data/vendas.csv"):
        self._total_dia = 0.0
        self._itens_vendidos = 0
        self.arquivo_vendas = arquivo_vendas
        self.arquivo_vendas_csv = arquivo_vendas_csv
        # Garante que o CSV tenha cabeçalho, caso não exixta
        if not os.path.exists(self.arquivo_vendas_csv):
            os.makedirs(os.path.dirname(self.arquivo_vendas_csv), exist_ok=True)
            with open(self.arquivo_vendas_csv, "w", encoding="utf-8", newline='') as f:
                writer = csv.writer(f)
                writer.writerow(["data_hora", "total", "itens", "forma", "cupom"])

    # Registra a venda atualizando e salvando histórico
    def registrar_venda(self, total_compra: float, itens_vendidos: int, 
                        forma: str, cupom: str = None):  
        self._total_dia += float(total_compra)
        self._itens_vendidos += int(itens_vendidos)
        # Cria o registro da venda
        venda = {
            "data_hora": datetime.datetime.now().isoformat(),
            "total": float(total_compra),
            "itens": int(itens_vendidos),
            "forma": forma,
            "cupom": cupom        
        }          
        # Garante a existência da pasta do arquivo JSON
        os.makedirs(os.path.dirname(self.arquivo_vendas), exist_ok=True)
        # Carrega as vendas já existentes (se houver)
        vendas = []
        if os.path.exists(self.arquivo_vendas):
            try:
                with open(self.arquivo_vendas, "r", encoding="utf-8") as f:
                    vendas = json.load(f)
            except Exception:
                vendas = []
        # Adiciona a nova venda e salva o JSON
        vendas.append(venda)
        with open(self.arquivo_vendas, "w", encoding="utf-8") as f:
            json.dump(vendas, f, ensure_ascii=False, indent=2)
        # Adiciona linha no CSV também
        with open(self.arquivo_vendas_csv, "a", encoding="utf-8", newline='') as f:
            writer = csv.writer(f)
            writer.writerow([venda["data_hora"], venda["total"], venda["itens"], venda["forma"], venda["cupom"]])  
    # Gerar o fechamento do caixa em arquivo TXT e imprimir no console
    def fechamento(self, pasta_reprots: str = "reports"):
        agora = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        nome_arquivo = os.path.join(pasta_reprots, f"fechamento_{agora}.txt")
        os.makedirs(os.path.dirname(nome_arquivo), exist_ok=True)
        with open(nome_arquivo, "w", encoding="utf-8") as f:
            f.write("### Fechamento do caixa ###\n")
            f.write(f"Total arrecadado no dia R$ {self._total_dia:.2f}\n")
            f.write(f"Total de itens vendidos: {self._itens_vendidos}\n")
            f.write("#######################################\n")
        print("### Fechamento do caixa ###")
        print(f"Total arrecadado no dia R$ {self._total_dia:.2f}")
        print(f"Total de itens vendidos: {self._itens_vendidos}")
        print(f"Relatório salvo em: {nome_arquivo}")              
        