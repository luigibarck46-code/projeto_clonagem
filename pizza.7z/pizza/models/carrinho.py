from models.produto import Produto
class Carrinho:
    # Cria um dicionário privado para armazenar itens (Produto->quantidade)
    def __init__(self):
        self.__pizzas = {}

    # Adiciona produto ao carrinho e reduz o estoque do produto
    def adicionar(self, produto: Produto, quantidade: int):
        quantidade = int(quantidade)
        if quantidade <= 0:
            raise ValueError("Quantidade deve ser maior que zero.")
        produto.reduzir_estoque(quantidade)
        if produto in self.__pizzas:
            self.__pizzas[produto] += quantidade
        else:
            self.__pizzas[produto] = quantidade

    # Remove unidades do carrinho e devolve ao estoque do produto
    def remover(self, produto: Produto, quantidade: int):
        quantidade = int(quantidade)
        if quantidade <= 0:
            raise ValueError("Quantidade inválida.")
        if produto in self.__pizzas:
            qtd_no_carrinho = self.__pizzas[produto]
            if quantidade >= qtd_no_carrinho:
                produto.aumentar_estoque(qtd_no_carrinho)
                del self.__pizzas[produto]
            else:
                self.__pizzas[produto] -= quantidade
                produto.aumentar_estoque(quantidade)

    # Retorna itens como iterável de pares (produto, quantidade)
    def listar_pizzas(self):
        return self.__pizzas.items()

    # Calcula o total do carrinho
    def calcular_total(self) -> float:
        return sum(produto.preco * qtd for produto, qtd in self.__pizzas.items())

    # Retorna o número total de unidades no carrinho
    def total_pizzas(self) -> int:
        return sum(qtd for qtd in self.__pizzas.values())

    # Indica se o carrinho está vazio
    def vazio(self) -> bool:
        return len(self.__pizzas) == 0                        

        