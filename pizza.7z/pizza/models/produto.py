class Produto:
    def __init__(self, codigo: int, sabor: str, tamanho: str, preco: float, estoque: int = 10, 
    estoque_minimo: int = 2):
        self._codigo = int(codigo)
        self._sabor = str(sabor)
        self._tamanho = tamanho
        self._preco = float(preco)
        self._estoque = int(estoque)
        self._estoque_minimo = int(estoque_minimo)

    @property
    def codigo(self) -> int:
        return self._codigo
    @property
    def nome(self) -> str:
        return self._sabor
    @property
    def tamanho(self) ->str:
        return self._tamanho
    @property
    def preco(self) -> float:
        return self._preco
    @property
    def estoque(self) -> int:
        return self._estoque
    @property
    def estoque_minimo(self) -> int:
        return self._estoque_minimo
    
    # Método para reduzir o estoque (usado ao adicionar ao carrinho)
    def reduzir_estoque(self, quantidade: int):
        quantidade = int(quantidade)
        if quantidade <= 0:
            raise ValueError("Quantidade deve ser positiva.")
        if quantidade > self._estoque:
            raise ValueError(f"Estoque insuficiente! Disponível: {self._estoque}")
        self._estoque -= quantidade

    # Método para aumentar o estoque (remoção do carrinho)
    def aumentar_estoque(self, quantidade: int):
        quantidade = int(quantidade)
        if quantidade <= 0:
            raise ValueError("Quantidade deve ser positiva.")
        self._estoque += quantidade

    # Atualizar o estoque para um valor específico
    def atualizar_estoque(self, nova_quantidade: int):
        nova_quantidade = int(nova_quantidade)
        if nova_quantidade < 0:
            raise ValueError("Estoque não pode ser negativo.")
        self._estoque = nova_quantidade

    # Atualiza o estoque mínimo
    def atualizar_estoque_minimo(self, novo_minimo: int):
        novo_minimo = int(novo_minimo)
        if novo_minimo < 0:
            raise ValueError("Estoque minimo não pode ser negativo.")
        self._estoque = novo_minimo

    # Indica se o produto está com estoque baixo
    def estoque_baixo(self) -> bool:
        return self._estoque <= self._estoque_minimo
    
    # Representa em string do produto para exibição no terminal
    def __str__(self) -> str:
        return f"[{self._codigo}] {self._sabor} - {self._tamanho} - R$ {self._preco:.2f} (Estoque: {self._estoque})"
    
    # Adicionando __eq__ e __hash__ para o carrinho funcionar corretamente
    def __eq__(self, other):
        if isinstance(other, Produto):
            return self._codigo == other._codigo
        return False
    
    def __hash__(self) -> int:
        return hash(self._codigo)
    
    # Converte o produto em dicionário para salvar em JSON
    def to_dict(self) -> dict:
        return {
            "codigo": self._codigo,
            "sabor": self._sabor,
            "tamanho": self._tamanho,
            "preço": self._preco,
            "estoque": self._estoque,
            "estoque_minimo": self._estoque_minimo
        }
        
    # Cria um produto a partir de um dicionário (útil ao carregar JSON)
    @staticmethod
    def from_dict(d: dict):
        return Produto(d["codigo"], d["nome"], d["tamanho"], d["preco"], d.get("estoque", 0), d.get("estoque_minimo", 2))
        