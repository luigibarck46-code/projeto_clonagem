# Funções auxiliares para ler e validar entradas do usuário
def ler_inteiro(mensagem: str) -> int:
    # Loop para receber um inteiro válido
    while True:
        try:
            return int(input(mensagem))
        except ValueError:
            print("Digite um número inteiro válido.")

def ler_float(mensagem: str) -> float:
    # Loop para receber um float válido
    while True:
        try:
            return float(input(mensagem))
        except ValueError:
            print("Digite um número válido (ex: 1.50).")

def ler_texto(mensagem: str) -> str:
    return input(mensagem)          

