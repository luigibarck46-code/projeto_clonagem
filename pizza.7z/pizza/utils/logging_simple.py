# Logging simples para registra eventos/erros
import datetime
import os

# Caminho para o arquivo de log
log_file = "logs/log.txt"
#Função que escreve uma linha de log 
def log(text: str):
    # Garante que a pasta exista
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now().isoformat()} - {text}\n")